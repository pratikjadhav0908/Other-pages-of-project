import React from "react";
import "./Thirdsection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Perks & Benefits of Registering a Pvt. Ltd. Company</h2>
          <h3>
            There are several advantages to registering a Pvt Ltd company:
          </h3>
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Limited liability Protection </h2>
            <p>
                In partnerships, personal savings and assets are at risk if the business fails to repay debts. A Pvt. Ltd. company ensures directors’ personal assets remain safe—only the invested capital is at stake.            </p>
          </div>
          <div className="one-section">
            <h2>Better Image and Market Credibility</h2>
            <p>
                Recognized as a trusted structure, Pvt. Ltd. companies are preferred by corporate clients, vendors, and government bodies over proprietorships or traditional partnerships.            </p>
          </div>
          <div className="one-section">
            <h2>Easy Fundraising & Loans</h2>
            <p>
                Compared to LLPs and OPCs, Pvt. Ltd. companies enjoy better access to bank loans, angel investments, and venture capital funding opportunities.            </p>
          </div>
          <div className="one-section">
            <h2>Investor-Friendly Structure</h2>
            <p>
                Well-organized with fewer restrictions, Pvt. Ltd. companies are the top choice for investors. They also offer smooth and quick exit options.            </p>
          </div>
          <div className="one-section">
            <h2>Attract & Retain Talent</h2>
            <p>
                The credibility of a Pvt. Ltd. structure makes it easier to hire employees and motivate them with professional designations and stock options, ensuring long-term commitment.            </p>
          </div>
          <div className="one-section">
            <h2>Easy to Sell</h2>
            <p>
Transferring ownership is simple, cost-effective, and requires minimal documentation, making a Pvt. Ltd. company easy to sell compared to other business forms.            </p>
          </div>
        </div>
      </div>
      <div className="requirement-section">
        <h1>Minimum Requirements for Pvt. Ltd. Registration</h1>
        <div className="remaining-section">
          <div className="two-section">
            <h2>Basic Requirements</h2>
            <ul>
                <li>Minimum 2 Shareholders</li>
              <li>
                Minimum 2 Directors (at least one must be an Indian resident)
              </li>
              <li>
                DSC (Digital Signature Certificate) for 2 promoters & 1 witness
              </li>
              <li>DIN (Director Identification Number) for all directors</li>
              <li>
                Minimum Authorised Share Capital - ₹1,00,000 (INR one Lakh)
              </li>
              <li>Directors and Shareholders can be the same individuals</li>
            </ul>
          </div>
          <div className="two-section">
            <h2>What's Included</h2>
            <ul className="remove-dot">
              <li>✔️ DIN for 2 Directors</li>
              <li>✔️ MOA & AOA (Memorandum and Articles of Association)</li>
              <li>✔️ DSC for 2 Promoters & 1 Witness</li>
              <li>✔️ Incorporation Certificate</li>
              <li>✔️ New Incorporation Kit</li>
              <li>✔️ Bank Account Opening Support</li>
              <li>✔️ Company PAN Card</li>
              <li>✔️ Domain + Web Hosting + 10 Email IDs (1 Year)</li>
              <li>✔️ Company TAN/TDS Number</li>
              <li>✔️ Company PAN Card</li>
              <li>✔️ Customized Incorporation Master File</li>
              <li>✔️ Company Name Approval</li>
              <li>✔️ Surprise Benefits worth ₹2,00,000 for 2 Partners</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
