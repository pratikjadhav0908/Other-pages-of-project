import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>Trademark</h2>
          <h2> Registration</h2>
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Trademark Registration in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to Trademark Registration</h2>
        <p>In today’s competitive business environment, protecting your brand name, logo, or tagline through trademark registration is essential for long-term success. This guide explains the process, fees, required documents, benefits, and key differences between trademark, copyright, and patent registration.</p>
      </div>
    </div>
  );
};

export default FirstSection;
