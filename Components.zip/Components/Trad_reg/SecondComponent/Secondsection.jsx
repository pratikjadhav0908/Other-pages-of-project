import React, { useState } from "react";
import "../SecondComponent/SecondSection.css";

const panels = ["categories", "process", "document", "cost"];

const Secondsection = () => {
  const [activeClass, setActiveClass] = useState("categories");
  const [exiting, setExiting] = useState(null);

  const Appearclass = (classid) => {
    if (classid === activeClass) return;

    setExiting(activeClass);

    setTimeout(() => {
      setExiting(null);
      setActiveClass(classid);
    }, 400); 
  };
  return (
    <div className="Secondsection">
      <div className="whole-part">
        <div className="header-section">
          {panels.map((panel) => (
            <p
              key={panel}
              className={activeClass === panel ? "active-class-menu" : ""}
              onClick={() => Appearclass(panel)}
            >
              {panel === "categories" && "Trademark, Copyright & Patent"}
              {panel === "process" && "Trademark Registration Process"}
              {panel === "document" && "Required Document for Registration"}
              {panel === "cost" && "Cost of Trademark Registration"}
            </p>
          ))}
        </div>
        <div className="description-section">
          <div className={`set-opacity ${
              activeClass === "categories" ? "active-class" : ""
            } ${exiting === "categories" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-first">
                 {/*<p>
                  In India, besides private limited companies, there are several
                  other types of company registrations. However, Pvt Ltd
                  incorporation continues to enjoy the highest trust among
                  customers, vendors, employees, investors, and bankers. Each
                  registration type comes with its own features, benefits, and
                  compliance requirements. To understand these better, you can
                  watch a detailed video after submitting the GET STARTED form
                  above.
                </p> */}
                <h3>Difference Between Trademark, Copyright & Patent :</h3>
                <ul>
                  <li>
                   Trademark → Protects brand elements like names, logos, symbols, and slogans 
                   that distinguish products/services in the marketplace.
                  </li>
                  <li>
                    Copyright → Protects creative works such as literature, music, 
                    art, films, and software from unauthorized reproduction or use.
                  </li>
                  <li>
                    Patent → Protects inventions and new technologies, granting the
                     inventor exclusive rights to produce, use, or sell it for a limited period.
                  </li>
                  
                </ul>
                {/* <p>
                  Apart from these, there are other business structures like
                  proprietorships and partnership firms. However, since these
                  are not registered companies, they generally carry a lower
                  trust score in the market.
                </p> */}
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "process" ? "active-class" : ""
            } ${exiting === "process" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-second">
                {/* <p>
                  Company Registration: Step-by-Step Process: Submit the
                  Consultation Form, and we’ll connect with you at the earliest.
                </p> */}
                <p>
                 The process of online trademark registration in India involves the following steps:
                </p>
                <ul>
                  <li>
                    Fill and submit the above Get Started Form.
                  </li>
                  <li>
                   Complete a simple Trademark Questionnaire.
                  </li>
                  <li>B&D Associates expert will address your queries</li>
                  <li>
                    Our legal team conducts a thorough Trademark Search
                  </li>
                  <li>
                    Drafting of the Trademark Description.
                  </li>
                  <li>
                   
                     Sign a one-page Authorization Letter.
                  </li>
                  <li>
                   Filing of the Trademark Application with the TM Registry.
                  </li>
                  <li>
                   Filing of the Trademark Application with the TM Registry.
                  </li>
                  <li>
                    Continuous tracking & guidance until approval.
                  </li>
                  
                </ul>
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "document" ? "active-class" : ""
            } ${exiting === "document" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-third">
                <p>
                  Here’s the list of Document Required for Trademark Registration in India:
                </p>
                <ul>
                  <li>Trademark Application Form.</li>
                  <li>
                    Proof of Identity & Address of Applicant.
                  </li>
                  <li>
                    Logo/Image of the Trademark (if applicable).
                  </li>
                  <li>
                    Details of Goods/Services covered under the trademark.
                  </li>
                  <li>
                    Authorization Letter/Power of Attorney.
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "cost" ? "active-class" : ""
            } ${exiting === "cost" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-forth">
                {/* <p>
                  The overall cost of Pvt Ltd company registration in India
                  differs based on the number of directors, share capital, and
                  professional charges.
                </p> */}
                <p>Trademark Registration Fees, Costs & Charges:</p>
                <ul>
                  <li>
                    Government Fee – Varies based on applicant type (individual/startup/company) and number of classes selected.
                  </li>
                  <li>
                   Professional Fee – Trademark consultant/attorney fees.
                  </li>
                  <li>
                    Other Charges – Applicable in case of objections, oppositions, or hearings.
                  </li>
                  
                </ul>
                {/* <p>
                  Professional fees for drafting and handling legal documents
                  form part of the extra costs.
                </p> */}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Secondsection;
