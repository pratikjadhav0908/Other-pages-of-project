import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>Renew your trademark</h2>
          
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Renew your trademark in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to Renew your trademark</h2>
        <p>Trademark renewal is essential to maintain your exclusive rights over a brand. By renewing on time, you protect your trademark from removal, ensure continuous ownership, and safeguard your brand identity in the market.</p>
      </div>
    </div>
  );
};

export default FirstSection;
