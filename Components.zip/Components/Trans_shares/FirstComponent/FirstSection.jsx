import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>Transfer of Shares</h2>
          
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Transfer of Shares in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to Transfer of Shares</h2>
        <p>Transfer of shares in a company must be properly documented and filed with the Registrar of Companies (ROC). This ensures legal compliance, updates the company’s records, and protects the rights of both transferor and transferee</p>
      </div>
    </div>
  );
};

export default FirstSection;
