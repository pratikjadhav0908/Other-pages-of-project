import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>Closure of OPC/LLP</h2>
         
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Closure of OPC/LLP in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to Closure of OPC/LLP</h2>
        <p>One Person Companies (OPC) and Limited Liability Partnerships (LLP) can be closed by following the legal winding-up or strike-off procedures with the Registrar of Companies (ROC). Proper closure ensures compliance, settles liabilities, and prevents future legal or financial issues.</p>
      </div>
    </div>
  );
};

export default FirstSection;
