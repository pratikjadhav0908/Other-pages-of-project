import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>Private Limited</h2>
          <h2>Company Registration</h2>
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Incorporate Your Company in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to Private Limited Company Registration</h2>
        <p>Private limited company registration is a favored option among Indian entrepreneurs as it offers legal recognition, director liability protection, credibility in the market, and enhanced trust. B&D Associates assists you throughout the registration journey, explaining the steps, required documents, costs, benefits, and resolving common queries.</p>
      </div>
    </div>
  );
};

export default FirstSection;
