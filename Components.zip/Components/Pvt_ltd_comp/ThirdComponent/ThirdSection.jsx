import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Key Benefits of Company Registration</h2>
          <h3>
            There are several advantages to registering a Pvt Ltd company:
          </h3>
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Limited liability Protection for directors personal assets.</h2>
            <p>
              Startups often need loans or credit to grow. In traditional
              partnerships, partners are personally liable, risking their
              savings and property if debts remain unpaid. A private limited
              company, however, provides limited liability protection—directors
              and shareholders risk only their investment in the business.
              Personal assets like homes, cars, and savings remain safe, making
              this structure highly secure.
            </p>
          </div>
          <div className="one-section">
            <h2>Enhanced reputation and credibility in the market.</h2>
            <p>
              A private limited company is one of the most recognized and
              trusted business structures in India. Corporate clients, vendors,
              and even government agencies often prefer working with private
              limited companies over proprietorships or partnerships. This
              preference enhances your brand image, builds credibility in the
              market, and makes it easier to secure contracts, partnerships, and
              growth opportunities.
            </p>
          </div>
          <div className="one-section">
            <h2>Easy fundraising and loan approvals for Company.</h2>
            <p>
              A Pvt. Ltd. company offers wider funding opportunities compared to
              LLPs and OPCs. It can easily raise capital through bank loans,
              angel investors, and venture capitalists, making it the preferred
              choice for entrepreneurs seeking business growth and expansion.
            </p>
          </div>
          <div className="one-section">
            <h2>Preferred business structure for investor</h2>
            <p>
              Investors prefer private limited companies because they are
              well-structured, professionally managed, and flexible. With fewer
              restrictions and higher credibility, they provide attractive
              investment opportunities. Most importantly, investors find it easy
              to exit, making them the most investor-friendly business
              structure.
            </p>
          </div>
          <div className="one-section">
            <h2>Easier to hire and retain employees</h2>
            <p>
              For startups, building a reliable team and retaining talent can be
              challenging. However, the credibility of a private limited
              structure makes it easier to attract skilled professionals.
              Employees gain confidence working in a recognized company and can
              be further motivated through corporate designations and stock
              option plans, ensuring long-term commitment and loyalty.
            </p>
          </div>
          <div className="one-section">
            <h2>Easy ownership transfer</h2>
            <p>
              A Private Limited company is easy to sell, requiring minimal
              documentation and low costs. Ownership transfer is simple through
              share sale, making exits faster compared to partnerships or
              proprietorships.
            </p>
          </div>
        </div>
      </div>
      <div className="requirement-section">
        <h1>Pvt. Ltd. Company Registration</h1>
        <div className="remaining-section">
          <div className="two-section">
            <h2>Basic Requirements</h2>
            <ul>
                <li>Minimum 2 Shareholders</li>
              <li>
                Minimum 2 Directors (at least one must be an Indian resident)
              </li>
              <li>
                DSC (Digital Signature Certificate) for 2 promoters and 1
                witness
              </li>
              <li>DIN (Director Identification Number) for all directors</li>
              <li>
                Suggested Authorised Share Capital - ₹20,000 (Twenty Thousand only)
              </li>
              <li>Directors and Shareholders can be the same individuals</li>
            </ul>
          </div>
          <div className="two-section">
            <h2>What's Included</h2>
            <ul className="remove-dot">
              <li>✔️ DIN for 2 Directors</li>
              <li>✔️ MOA & AOA (Memorandum and Articles of Association)</li>
              <li>✔️ Customized Incorporation Master File</li>
              <li>✔️ Bank Account Opening Support</li>
              <li>✔️ Digital Signature Token for 2 Promoters & 1 Witness</li>
              <li>✔️ Certificate of Incorporation</li>
              <li>✔️ Company PAN Card</li>
              <li>✔️ Company TAN/TDS Registration</li>
              <li>✔️ PF, ESIC & Professional Tax Registration</li>
              <li>✔️ Company Name Approval</li>
              <li>✔️ Web Domain Name (1 Year)</li>
              <li>✔️ Web Hosting + 10 Email Accounts (1 Year)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
