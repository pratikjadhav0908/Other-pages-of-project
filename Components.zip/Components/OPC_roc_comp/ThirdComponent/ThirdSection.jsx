import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Mandatory Compliances & Penalties</h2>
          <h3>
           (Applicable for all companies under Companies Act, 2013):
          </h3>
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Issue of Share Certificates.</h2>
            <p>
              <ul>
                <li>Timeline: Within 2 months of incorporation or new allotment.</li>
                <li><b>Penalty:</b>
                  <ul>
                    <li>Company: ₹25,000 – ₹5,00,000</li>
                    <li>Directors: ₹10,000 – ₹1,00,000</li>
                  </ul>
                </li>
              </ul>
            </p>
          </div>
          <div className="one-section">
            <h2>Statutory Registers.</h2>
            <p>
             <ul>
              <li>Requirement: Maintain and update 7–8 mandatory registers regularly.</li>
              <li><b>Penalty:</b>
              <ul>
                <li>₹50,000 – ₹3,00,000</li>
                <li>Additional fine: ₹1,000 per day of continued default</li>
              </ul>
              </li>
             </ul>
            </p>
          </div>
          <div className="one-section">
            <h2>Annual ROC Filings (w.e.f 01/04/2014).</h2>
            <p>
              <ul>
                <li><b>Required Filings:</b>
                  <ul>
                    <li>MGT-7 (Annual Return) – within 60 days of meeting/event</li>
                    <li>AOC-4 (Financial Statements) – within 180 days of financial year end</li>
                    <li>ADT-1 (Auditor Appointment) – within 15 days of meeting/event</li>
                  </ul>
                </li>
                <li><b>Penalty:</b>
                  <ul>
                    <li>Additional ROC fees: Up to 12× normal fees per form</li>
                    <li>Company: ₹50,000 – ₹5,00,000</li>
                    <li>Directors: Imprisonment up to 6 months or fine ₹50,000 – ₹5,00,000 or both</li>
                  </ul>
                </li>
              </ul>
            </p>
          </div>
          <div className="one-section">
            <h2>Board Meeting Compliances (for OPCs with more than 1 director)</h2>
            <p>
              <ul>
                <li> <b>Requirement:</b>
                  <ul>
                    <li>1st board meeting within 30 days of incorporation</li>
                    <li>One board meeting per quarter</li>
                    <li>Maintain minutes, give notice, and record attendance</li>
                  </ul>
                </li>
                <li><b>Penalty:</b>
                  <ul>
                    <li>Company: ₹25,000</li>
                    <li>Director: ₹5,000</li>
                    <li>Failure to issue notice: ₹25,000 penalty</li>
                  </ul>
                </li>
              </ul>
            </p>
          </div>
          
        </div>
      </div>
      
    </div>
  );
};

export default Thirdsection;
