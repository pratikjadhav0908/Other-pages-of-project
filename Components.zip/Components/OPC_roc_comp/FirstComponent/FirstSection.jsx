import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>OPC ROc Complianc AMC</h2>
          {/* <h2>Company Registration</h2> */}
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>OPC ROc Complianc AMC in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to OPC ROc Complianc AMC </h2>
        <p>Every registered company must follow key compliances such as issuing share certificates within 2 months, maintaining statutory registers, filing annual ROC returns (MGT-7, AOC-4, ADT-1) on time, and holding regular board meetings. Non-compliance attracts heavy penalties, daily fines, or even imprisonment for directors in default.</p>
      </div>
    </div>
  );
};

export default FirstSection;
