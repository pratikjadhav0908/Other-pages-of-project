import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>Startup India</h2>
          <h2>Scheme</h2>
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Startup India Scheme in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to Startup India Scheme</h2>
        <p>Startup India Scheme is a flagship initiative launched by the Government of India to promote entrepreneurship, innovation, and job creation. The scheme offers recognized startups various
          benefits such as tax exemptions, funding support, simplified compliance, priority in government tenders, and rebates on intellectual property rights (IPR) filings. It is designed to provide
           an enabling ecosystem that helps startups grow, scale, and compete globally.</p>
      </div>
    </div>
  );
};

export default FirstSection;
