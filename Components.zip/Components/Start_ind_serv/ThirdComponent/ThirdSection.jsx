import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Key Benefits of Startup India Scheme</h2>
          <h3>
            There are several advantages to Startup India Scheme:
          </h3>
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Eligibility to Apply for 3 Years Income Tax Exemption.</h2>
            <p>
              Recognised startups can claim complete income tax exemption for any 3 consecutive years out of the first 10 years since incorporation.
               This relief allows founders to reinvest profits into scaling operations, hiring talent, and product development without the burden of early-stage taxation.
            </p>
          </div>
          <div className="one-section">
            <h2>Eligibility to Avail Funding from ₹10,000 Crore FOF Scheme.</h2>
            <p>
              The government has set up a Fund of Funds for Startups (FOF) with a corpus of ₹10,000 crore. Already, over ₹1,600 crore has
               been invested across 250+ startups. Eligible startups can tap into the remaining funds, gaining easier access to venture capital support and government-backed credibility.
            </p>
          </div>
          <div className="one-section">
            <h2>Priority in Government Tenders & Procurement Schemes.</h2>
            <p>
              Startups get exemptions from prior experience, turnover requirements, and security deposits while applying for government tenders. Additionally, 
              they can list their products/services on the Government e-Marketplace (GeM), ensuring wider visibility and direct access to public procurement opportunities.
            </p>
          </div>
          <div className="one-section">
            <h2>No Angel Tax up to ₹25 Crore Funding</h2>
            <p>
              Investments made by accredited investors, non-residents, AIFs, or closely held listed companies into eligible startups are exempt from the controversial Angel Tax (Section 56(2)(viib)) for funding up to ₹25 crore.
               This benefit ensures startups can raise capital without worrying about heavy tax liabilities on share premiums.
            </p>
          </div>
          <div className="one-section">
            <h2>Freedom from Labour Law Inspections</h2>
            <p>
              Recognised startups are free from routine inspections under labour laws. They can self-manage compliances for PF,
               ESIC, gratuity, and environmental regulations through simple online declarations. This reduces bureaucratic hurdles and gives entrepreneurs peace of mind.
            </p>
          </div>
          <div className="one-section">
            <h2>50% Discount in Trademark Fees & 80% Rebate in Patent Filing</h2>
            <p>
              Startups receive fast-tracked examination of patent applications along with significant fee reductions — 50% discount
               on trademarks and up to 80% rebate in patent filing. This helps protect intellectual property affordably and quickly.
            </p>
          </div>
          <div className="one-section">
            <h2>Easy Foreign Loan Access (ECB up to $3 Million)</h2>
            <p>
             Startups can now borrow up to $3 million per financial year from foreign investors
              under the External Commercial Borrowing (ECB) route. The RBI has simplified compliance norms, making foreign capital raising a smoother process.
            </p>
          </div>
          <div className="one-section">
            <h2>Private Limited Companies Allowed to Take Deposits from Members</h2>
            <p>
              For the first five years after incorporation, recognised startups registered as Private Limited Companies can accept
               deposits from their members. This provides an additional financing option without resorting to external borrowing.
            </p>
          </div>
          <div className="one-section">
            <h2>Eligibility for State Government Incentives</h2>
            <p>
              Apart from central benefits, many states like Maharashtra, Karnataka, and Gujarat offer extra 
              rebates on GST, loans, electricity charges, and capital subsidies. Startups registered under Startup India can access these state-specific schemes, multiplying their advantages.
            </p>
          </div>
        </div>
      </div>
      <div className="requirement-section">
        <h1>Startup India Scheme Registration</h1>
        <div className="remaining-section">
          <div className="two-section">
            <h2>Documents Required</h2>
            <ul>
                <li>Certificate of Incorporation (Company/LLP/Partnership)</li>
              <li>
                Brief write-up explaining how the business is innovative & contributes to employment/wealth creation
              </li>
              <li>
                Company PAN Card
              </li>
              <li>Website link or Company Profile Deck (any one)</li>
              {/* <li>
                Suggested Authorised Share Capital - ₹20,000 (Twenty Thousand only)
              </li>
              <li>Directors and Shareholders can be the same individuals</li> */}
            </ul>
          </div>
          <div className="two-section">
            <h2>Eligibility for Startup India Registration</h2>
            <ul className="remove-dot">
              <li>✔️ Be registered as a Private Limited Company, LLP, or Partnership Firm</li>
              <li>✔️ Not be older than 10 years from incorporation</li>
              <li>✔️ Offer an innovative product, process, or service</li>
              <li>✔️ Have a turnover not exceeding ₹100 crore in any financial year</li>
              <li>✔️ Demonstrate high potential for employment generation or wealth creation</li>
              {/* <li>✔️ Certificate of Incorporation</li>
              <li>✔️ Company PAN Card</li>
              <li>✔️ Company TAN/TDS Registration</li>
              <li>✔️ PF, ESIC & Professional Tax Registration</li>
              <li>✔️ Company Name Approval</li>
              <li>✔️ Web Domain Name (1 Year)</li>
              <li>✔️ Web Hosting + 10 Email Accounts (1 Year)</li> */}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
