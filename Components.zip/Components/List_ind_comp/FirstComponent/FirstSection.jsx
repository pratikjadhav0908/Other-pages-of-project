import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>list of indian companies</h2>
          
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>list of indian companies in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to list of indian companies</h2>
        <p>The Ministry of Corporate Affairs (MCA) maintains an official list of all registered companies in India, including Private Limited Companies, Public Limited Companies, LLPs, and OPCs. This database provides details such as company name, registration number, directors, and compliance status, helping stakeholders verify authenticity and make informed business decisions.</p>
      </div>
    </div>
  );
};

export default FirstSection;
