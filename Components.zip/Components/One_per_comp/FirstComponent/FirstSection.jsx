import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../Assets/form.png';

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>One Person</h2>
          <h2>Company Registration</h2>
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Incorporate Your Company in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
     <div className="step-wise-guide">
        <h2>GUIDE TO ONE PERSON COMPANY REGISTRATION IN INDIA</h2>
        <p>In India, the One Person Company (OPC) has become a preferred choice for solo entrepreneurs who wish to start a business with limited liability protection and simplified compliance requirements. This unique structure empowers a single individual to establish and manage a company, while still enjoying many of the advantages of a private limited company, such as credibility, legal recognition, and business continuity. <br />In this comprehensive guide, we’ll walk you through the complete OPC registration process, including the step-by-step procedure, required documents, applicable fees, and key benefits, helping you clearly understand how to get your OPC registered in India with ease.</p>
      </div> 
    </div>
  );
};

export default FirstSection;
