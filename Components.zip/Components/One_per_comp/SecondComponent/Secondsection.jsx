import React, { useState } from "react";
import "./Secondsection.css";

const panels = ["categories", "process", "document", "cost"];

const Secondsection = () => {
  const [activeClass, setActiveClass] = useState("categories");
  const [exiting, setExiting] = useState(null);

  const Appearclass = (classid) => {
    if (classid === activeClass) return;

    setExiting(activeClass);

    setTimeout(() => {
      setExiting(null);
      setActiveClass(classid);
    }, 400); 
  };
  return (
    <div className="Secondsection">
      <div className="whole-part">
        <div className="header-section">
          {panels.map((panel) => (
            <p
              key={panel}
              className={activeClass === panel ? "active-class-menu" : ""}
              onClick={() => Appearclass(panel)}
            >
              {panel === "categories" && "Pvt Ltd & OPC Difference"}
              {panel === "process" && "Company Registration Process"}
              {panel === "document" && "Required Document for Registration"}
              {panel === "cost" && "Cost of Company Registration"}
            </p>
          ))}
        </div>
        <div className="description-section">
          <div className={`set-opacity ${
              activeClass === "categories" ? "active-class" : ""
            } ${exiting === "categories" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-first">
                {/* <p>
                  In India, besides private limited companies, there are several
                  other types of company registrations. However, Pvt Ltd
                  incorporation continues to enjoy the highest trust among
                  customers, vendors, employees, investors, and bankers. Each
                  registration type comes with its own features, benefits, and
                  compliance requirements. To understand these better, you can
                  watch a detailed video after submitting the GET STARTED form
                  above.
                </p> */}
                <h3>Difference Between One Person Company & Private Limited Company in India:</h3>
                <ul>
                  <li>
                    Number of Members: An OPC can have only one member, while a Private Limited Company requires at least two members and allows up to 200 members.
                  </li>
                  <li>
                    Nominee Requirement: An OPC must appoint a natural person as a nominee, whereas a Private Limited Company has no such requirement.
                  </li>
                  <li>
                    Conversion: OPCs have stricter conversion rules, while Private Limited Companies can convert into other business structures more easily.
                  </li>
                  
                </ul>
                <p>
                  For detailed guidance, you can consult B&D Associates OPC Registration experts.
                </p>
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "process" ? "active-class" : ""
            } ${exiting === "process" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-second">
                {/* <p>
                  Company Registration: Step-by-Step Process: Submit the
                  Consultation Form, and we’ll connect with you at the earliest.
                </p>
                <p>
                  The process of registering a Pvt Ltd company in India involves
                  specific legal steps, which can be outlined as follows:
                </p> */}
                <ul>
                  <li>
                    <b>Fill & Submit Form :</b> Start by filling out the above GET STARTED form with your basic details. This helps us understand your requirements and initiate the process.
                  </li>
                  <li>
                    <b>Watch Guidance Video:</b>Once submitted, you will get access to a detailed explainer video on OPC incorporation, giving you clarity about the process, documents, timeline, and compliance.
                  </li>
                  
                  <li>
                    <b>Submit OPC Questionnaire:</b> You’ll be asked to complete a simple one-page questionnaire about your business idea, proposed name, and founder details to help us draft documents accurately.
                  </li>
                  <li>
                    <b>Expert Consultation:</b> The team at B&D Associates will personally review your details, resolve queries, and provide expert advice on name selection, structure, and compliances.
                  </li>
                  <li>
                    <b>
                     Arrange Documents:
                    </b>
                    The founder needs to provide simple ID proofs (PAN, Aadhaar, Passport, etc.), address proof, and recent utility bill or bank statement as residential proof.
                  </li>
                  <li>
                    <b>Sign Documents:</b>Based on your details, incorporation papers such as consent forms, declarations, and affidavits are prepared and sent for your signature.
                  </li>
                  <li>
                    <b>Name Application & Drafting:</b> A unique business name is applied through the MCA portal. At the same time, the Memorandum of Association (MoA) and Articles of Association (AoA) are drafted, clearly stating your business objectives and internal rules.
                  </li>
                  <li>
                    <b>File Incorporation Forms:</b> Once the documents are ready, incorporation forms (like SPICe+) are filed online with the Ministry of Corporate Affairs along with DSC and DIN applications.
                  </li>
                  <li>
                    <b>Certificate of Incorporation:</b> After verification, the Registrar of Companies issues the Certificate of Incorporation, making your OPC a legally registered entity.
                  </li>
                  <li>
                    <b>PAN & TAN Allotment :</b> Along with the incorporation certificate, your company automatically receives a Permanent Account Number (PAN) and a Tax Deduction & Collection Account Number (TAN) for smooth tax compliance.
                  </li>
                  <li>
                    <b>Bank Account Support :</b> B&D Associates also assists in preparing the necessary documents to open a current bank account in your OPC’s name, enabling you to officially start business operations.
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "document" ? "active-class" : ""
            } ${exiting === "document" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-third">
                <p>
                  Here’s the list of documents needed to register a One Person
                  company in India:
                </p>
                <ul>
                  <li>Identity Proof – PAN card, Aadhaar card, or Passport of the proposed Director.</li>
                  <li>
                    Address Proof – Recent utility bill or bank statement showing residential address.
                  </li>
                  <li>
                    Passport-sized Photographs – Photographs of the proposed Director.
                  </li>
                  <li>
                    Proof of Registered Office – Rental agreement, utility bill, or property tax receipt of the office premises.
                  </li>
                  <li>
                    No Objection Certificate (NOC) – If the office is rented, NOC from the property owner.
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "cost" ? "active-class" : ""
            } ${exiting === "cost" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-forth">
                <p>
                  The cost of registering a One Person Company (OPC) in India depends on the authorised capital and the state of incorporation.
                </p>
                <p>Government charges for company registration include:</p>
                <ul>
                  <li>
                    DSC Fee:Cost of obtaining a Digital Signature Certificate for the promoter.
                  </li>
                  <li>
                    DIN Fee: Fees for obtaining Director Identification Number (DIN) .
                  </li>
                  <li>
                    Name Approval Fee: Charges for reserving the company name with MCA.
                  </li>
                  <li>
                    Registration Fee: Varies based on the authorised capital of the company.
                  </li>
                </ul>
                <p>
                  Professional Charges : Legal, compliance, and facilitation support fees.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Secondsection;
