import React from "react";
import "./Thirdsection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Benefits of One Person company Registration</h2>
          <h3>
            There are several advantages to registering a One Person company:
          </h3>
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Limited Liability Protection to Personal Assets.</h2>
            <p>
                Startups often need loans or credit. In partnerships, personal savings and property are at risk if debts cannot be repaid. In an OPC, only the business investment is lost—personal assets remain safe.            </p>
          </div>
          <div className="one-section">
            <h2>Better Image and Market Credibility</h2>
            <p>
              An OPC is recognized as a Private Limited Company, one of the most trusted business structures in India. Corporate clients, vendors, and government agencies prefer dealing with it over proprietorships.
            </p>
          </div>
          <div className="one-section">
            <h2>Easy to Manage & Raise Funds</h2>
            <p>
              OPC is simple to operate with minimal ROC filings, no AGM requirements, and fewer compliances. This structure makes it easier to access loans and future funding options.
            </p>
          </div>
          <div className="one-section">
            <h2>Testing Business Model & Attracting Investors</h2>
            <p>
                An OPC helps entrepreneurs test their business model efficiently. Once validated, it can easily be converted into a multi-shareholder Pvt. Ltd. Company, attracting angel investors and venture capital funding.            </p>
          </div>
          <div className="one-section">
            <h2>Complete Control with Single Owner</h2>
            <p>
                The single-owner model ensures quick decisions and faster execution. Still, OPCs can appoint up to 15 directors for operational needs without diluting ownership.            </p>
          </div>
          <div className="one-section">
            <h2>Easy Exit & Transferability</h2>
            <p>
                Selling an OPC is simple, with minimal documentation and lower costs, making it easier for entrepreneurs to exit when needed.            </p>
          </div>
        </div>
      </div>
      <div className="requirement-section">
        <h1>One Person Company Registration</h1>
        <div className="remaining-section">
          <div className="two-section">
            <h2>Basic Requirements</h2>
            <ul>
                <li>Minimum 1 Shareholders</li>
              <li>
                Minimum 1 Nominee
              </li>
              <li>
                Minimum 1 Director (at least one must be an Indian resident)
              </li>
              <li>DIN (Director Identification Number) for all directors</li>
              <li>
                DSC (Digital Signature Certificate) for 1 Promoter & 1 Witness
              </li>
              <li>Minimum Authorised Share Capital – ₹1,00,000 (One Lakh)</li>
              <li>
                Director and Shareholder can be the same person
              </li>
              <li>Only Indian residents can be Shareholder & Nominee</li>
            </ul>
          </div>
          <div className="two-section">
            <h2>What's Included</h2>
            <ul className="remove-dot">
              <li>✔️ DIN for 1 Directors</li>
              <li>✔️ MOA & AOA (Memorandum and Articles of Association)</li>
              <li>✔️ Customized Incorporation Master File</li>
              <li>✔️ Bank Account Opening Support</li>
              <li>✔️ Digital Signature Token for 1 Promoters & 1 Witness</li>
              <li>✔️ Certificate of Incorporation</li>
              <li>✔️ Company PAN Card</li>
              <li>✔️ Company TAN/TDS Registration</li>
              <li>✔️ PF, ESIC & Professional Tax Registration</li>
              <li>✔️ Company Name Approval</li>
              <li>✔️ Web Domain Name (1 Year)</li>
              <li>✔️ Web Hosting + 10 Email Accounts (1 Year)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
