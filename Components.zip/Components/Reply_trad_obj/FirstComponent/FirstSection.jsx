import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>Reply to trademark </h2>
          <h2>objection</h2>
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Reply to trademark objection in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to Reply to trademark objection</h2>
        <p>Trademark opposition arises when a third party challenges your application after it is published in the journal. To protect your brand, it is crucial to file a strong counter-statement with valid documents and arguments within the prescribed time. Timely response ensures your rights are safeguarded and the registration process continues smoothly.</p>
      </div>
    </div>
  );
};

export default FirstSection;
