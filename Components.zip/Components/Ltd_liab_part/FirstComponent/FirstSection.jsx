import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>Limited Liability</h2>
          <h2>Partnership</h2>
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Limited Liability Partnership in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>LLP Registration: Step-by-Step Guide</h2>
        <p>A Limited Liability Partnership (LLP) is one of the most preferred business structures among entrepreneurs due to its flexibility and compliance advantages. B&D Associates guides you through the complete process of registering an LLP, covering the key steps, required documents, costs, benefits, and addressing frequently asked questions. We’ll also highlight the differences between LLPs and other business structures like Pvt. Ltd., OPC, and traditional partnerships.</p>
      </div>
    </div>
  );
};

export default FirstSection;
