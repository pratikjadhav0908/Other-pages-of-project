import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Key Benefits of Limited Liability Partnership Registration</h2>
          <h3>
            There are several advantages to registering Limited Liability Partnership:
          </h3>
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Limited Liability Protection.</h2>
            <p>
              In traditional partnerships, partners’ personal assets are at risk if the business fails. 
              In an LLP, only the amount contributed as capital is at risk, ensuring partners’ personal wealth remains protected.
            </p>
          </div>
          <div className="one-section">
            <h2>Better Image & Market Credibility.</h2>
            <p>
              LLPs are recognized worldwide as credible business structures. 
              Corporates, vendors, and government bodies prefer working with LLPs instead of proprietorships or simple partnerships.
            </p>
          </div>
          <div className="one-section">
            <h2>No Mandatory Audit & Low Compliance.</h2>
            <p>
              LLPs are easy to manage. Statutory audits are not required unless capital exceeds ₹25 lakh or turnover exceeds ₹40 lakh. 
              This makes them cost-effective and ideal for small businesses and startups.
            </p>
          </div>
          <div className="one-section">
            <h2>Business Continuity</h2>
            <p>
             An LLP enjoys perpetual succession, meaning it continues to exist even if partners leave or change. 
             This ensures stability and continuity, unlike traditional partnerships.
            </p>
          </div>
          {/* <div className="one-section">
            <h2>Easier to hire and retain employees</h2>
            <p>
              For startups, building a reliable team and retaining talent can be
              challenging. However, the credibility of a private limited
              structure makes it easier to attract skilled professionals.
              Employees gain confidence working in a recognized company and can
              be further motivated through corporate designations and stock
              option plans, ensuring long-term commitment and loyalty.
            </p>
          </div>
          <div className="one-section">
            <h2>Easy ownership transfer</h2>
            <p>
              A Private Limited company is easy to sell, requiring minimal
              documentation and low costs. Ownership transfer is simple through
              share sale, making exits faster compared to partnerships or
              proprietorships.
            </p>
          </div> */}
        </div>
      </div>
      <div className="requirement-section">
        <h1>Limited Liability Partnership Registration</h1>
        <div className="remaining-section">
          <div className="two-section">
            <h2>Basic Requirements</h2>
            <ul>
                <li>Minimum 2 Partners</li>
              <li>
                DIN (Director Identification Number) for all Designated Partners
              </li>
              <li>
               DSC (Digital Signature Certificate) for all Designated Partners
              </li>
              <li>If a corporate body is a partner, it must nominate a natural person</li>
              <li>
                No minimum share capital required (partners must contribute agreed capital)
              </li>
              <li>Registered Office Proof of the LLP</li>
            </ul>
          </div>
          <div className="two-section">
            <h2>What's Included</h2>
            <ul className="remove-dot">
              <li>✔️ DIN for 2 Partners</li>
              <li>✔️ Digital Signature for 1 Partner</li>
              <li>✔️ Certificate of Incorporation</li>
              <li>✔️ LLP PAN Card</li>
              <li>✔️ LLP TAN/TDS Registration</li>
              <li>✔️ LLP Agreement</li>
              <li>✔️ Customized Master File of Incorporation Documents</li>
              <li>✔️ Bank Account Opening Support</li>
              <li>✔️ Web Domain Name (1 Year)</li>
              <li>✔️ Web Hosting + 10 Email Accounts (1 Year)</li>
              <li>✔️ Dedicated Service Manager</li>
              
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
