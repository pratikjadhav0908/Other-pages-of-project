import React, { useState } from "react";
import "../SecondComponent/SecondSection.css";

const panels = ["categories", "process", "document", "cost"];

const Secondsection = () => {
  const [activeClass, setActiveClass] = useState("categories");
  const [exiting, setExiting] = useState(null);

  const Appearclass = (classid) => {
    if (classid === activeClass) return;

    setExiting(activeClass);

    setTimeout(() => {
      setExiting(null);
      setActiveClass(classid);
    }, 400); 
  };
  return (
    <div className="Secondsection">
      <div className="whole-part">
        <div className="header-section">
          {panels.map((panel) => (
            <p
              key={panel}
              className={activeClass === panel ? "active-class-menu" : ""}
              onClick={() => Appearclass(panel)}
            >
              {panel === "categories" && "How to Register an LLP in India?"}
              {panel === "process" && "Steps for Online LLP Registration"}
              {panel === "document" && "Required Document for LLP Registration"}
              {panel === "cost" && "Cost of LLP Registration"}
            </p> 
          ))}
        </div>
        <div className="description-section">
          <div className={`set-opacity ${
              activeClass === "categories" ? "active-class" : ""
            } ${exiting === "categories" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-first">
                <p>
                 Registering an LLP in India is a completely online process governed by the Ministry of Corporate Affairs (MCA). It begins with obtaining Digital Signature Certificates (DSC) for all designated partners, followed by applying for their Director Identification Numbers (DIN).
                  The next step is reserving a unique name through the MCA portal, after which the incorporation form (FiLLiP) is filed along with the required documents. Once approved, the Registrar of Companies issues the Certificate of Incorporation, officially recognizing the LLP as a legal entity.
                  An LLP Agreement, defining the rights and duties of partners, must then be filed within 30 days of incorporation. After incorporation, the LLP is allotted a PAN and TAN, enabling tax compliance, and a bank account can be opened in the name of the LLP to commence operations.
                </p>
                {/* <h3>Types of Company Registrations in India:</h3>
                <ul>
                  <li>
                    One Person Company (OPC): Best suited for solo
                    entrepreneurs, OPC allows a single individual to own all
                    shares and manage the business.
                  </li>
                  <li>
                    Limited Liability Partnership (LLP): LLP offers the
                    flexibility of a partnership while providing limited
                    liability protection to its partners.
                  </li>
                  <li>
                    Public Limited Company: Ideal for large-scale businesses, as
                    it enables the company to raise capital by offering shares
                    to the public.
                  </li>
                  <li>
                    Section 8 Company (Non-Profit): Designed for NGOs and
                    non-profit organizations aiming to promote charitable or
                    social objectives.
                  </li>
                </ul>
                <p>
                  Apart from these, there are other business structures like
                  proprietorships and partnership firms. However, since these
                  are not registered companies, they generally carry a lower
                  trust score in the market.
                </p> */}
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "process" ? "active-class" : ""
            } ${exiting === "process" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-second">
                <p>
                 Before beginning the LLP registration process, it is important to understand its benefits.
                  An LLP combines the features of both a partnership and a company, offering its partners the advantage of limited liability while retaining the flexibility of a partnership structure.
                </p>
                <p>
                  Registering an LLP in India involves a few specific legal steps:
                </p>
                <ul>
                  <li>
                    <b>Filling the Form :</b> Once the registration form is submitted, we will connect with you to initiate your LLP incorporation process.
                  </li>
                  <li>
                    <b>Watch a Detailed Video :</b> Learn about LLP formation through our step-by-step guide video.
                  </li>
                  <li>
                    <b>Submit One-Page Questionnaire :</b> Provide basic details through a simple questionnaire to proceed further.
                  </li>
                  <li>
                    <b>Expert Consultation :</b> Our team will resolve your queries and guide you at every step.
                  </li>
                  <li>
                    <b>Arrange Partner ID & Address Proofs:</b> Partners need to submit simple KYC documents.
                  </li>
                  <li>
                    <b> Signing of Incorporation Documents :</b>
                    Legal documents will be drafted and signed by the partners.
                  </li>
                  <li>
                    <b>Drafting Object & Name Application :</b> We help draft your main business object and apply for name approval.
                  </li>
                  <li>
                    <b>Approval & Incorporation Certificate:</b> After
                    verification, the Registrar of Companies (RoC) issues the
                    Certificate of Incorporation, confirming the company’s legal
                    existence.
                  </li>
                  <li>
                    <b>Filing with MCA :</b> Incorporation forms are filed with the Ministry of Corporate Affairs.
                  </li>
                  <li>
                    <b>Certificate of Incorporation :</b> Once approved, you will receive the official incorporation certificate.
                  </li>
                  <li>
                    <b>LLP Agreement Filing:</b>The LLP Agreement is filed with MCA to complete the process.
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "document" ? "active-class" : ""
            } ${exiting === "document" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-third">
                <p>
                  Here’s the list of documents needed to LLP Registration in India:
                </p>
                <ul>
                  <li>Partner’s PAN Card – Identity proof.</li>
                  <li>
                    Address Proof of Partners – Aadhaar Card, Voter ID, etc.
                  </li>
                  <li>
                    Registered Office Proof – Latest utility bill (electricity/water).
                  </li>
                  <li>
                    NOC from Owner – If the office is rented.
                  </li>
                  <li>
                    Passport-size Photographs – of partners.
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "cost" ? "active-class" : ""
            } ${exiting === "cost" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-forth">
                {/* <p>
                  The overall cost of Pvt Ltd company registration in India
                  differs based on the number of directors, share capital, and
                  professional charges.
                </p> */}
                <p>LLP Registration Fees, Costs & Charges:</p>
                <ul>
                  <li>
                    Name Approval Fee – Charges for reserving the LLP name.
                  </li>
                  <li>
                    DSC Fee – For obtaining DSC of partners.
                  </li>
                  <li>
                    DIN Fee – For obtaining DIN of designated partners.
                  </li>
                  <li>
                    Registration Fee – Varies as per capital contribution & state.
                  </li>
                  <li>
                    Professional Charges – For legal documentation and facilitation.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Secondsection;
