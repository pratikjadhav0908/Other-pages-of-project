import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Eligibility for GST Registration :</h2>
          <h3>
            GST Registration is mandatory for certain businesses as per GST law. Here’s who needs to register:
          </h3> 
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Upon Reaching Turnover of ₹20 Lakh</h2>
            <p>
              If your supply of goods or services exceeds ₹20 lakh in a financial year, GST registration is compulsory. (For businesses operating exclusively in North Eastern and hill states, the limit is ₹10 lakh).
            </p>
          </div>
          <div className="one-section">
            <h2>Inter-State Sales or Service Providers.</h2>
            <p>
              Any person or company supplying goods or services from one state to another must register under GST, regardless of turnover. Even online service providers serving customers in another state are covered.
            </p>
          </div>
          <div className="one-section">
            <h2>E-Commerce Operators.</h2>
            <p>
              Owners or operators of digital platforms (like Amazon, Flipkart, etc.) that facilitate e-commerce are required to register.
            </p>
          </div>
          <div className="one-section">
            <h2>Vendors Selling through E-Commerce Portals</h2>
            <p>
              Suppliers who sell goods or services via e-commerce platforms must obtain GST registration.
            </p>
          </div>
          <div className="one-section">
            <h2>Non-Residents & Importers</h2>
            <p>
              Any non-resident person or foreign company supplying goods or services in India must register under GST, irrespective of turnover.
            </p>
          </div>
          <div className="one-section">
            <h2>Suppliers of Online Information & Database Services</h2>
            <p>
              Overseas businesses providing online information or database access (OIDAR services) to individuals in India must also register, even without a physical presence in India.
            </p>
          </div>
        </div>
      </div>
      <div className="requirement-section">
        <h1>GST Registration</h1>
        <div className="remaining-section">
          <div className="two-section">
            <h2>Difference Between CGST, SGST & IGST</h2>
            <ul>
                <li><b>Central GST (CGST)</b> <br />Levied by the Central Government on intra-state transactions (supplier and consumer in the same state).</li>
              <li><b>State GST (SGST)</b> <br />Levied by the respective State Government on intra-state supply of goods and services.</li>
              <li><b>Integrated GST (IGST)</b> <br />Levied by the Central Government on inter-state transactions (supplier and consumer in different states). Only IGST is applicable in such cases.</li>
              
              
            </ul>
          </div>
          <div className="two-section">
            <h2>Documents Required for GST Registration</h2>
            <ul className="remove-dot">
              <li>1️⃣ <b>For Pvt. Ltd. / Public Ltd. / OPC </b> <br />✔️ Company PAN card <br />✔️ MOA, AOA & Incorporation Certificate <br />✔️Company Address Proof</li>
              <li>2️⃣ <b>For LLP & Partnership Firm</b> <br />✔️ Firm PAN card <br />✔️ LLP Agreement / Partnership Deed <br />✔️ Firm Address Proof</li>              
              <li>3️⃣ <b>For Proprietorship Firm</b> <br />✔️ Proprietor's PAN card <br />✔️ Shop Act / Gumasta License <br />✔️ Firm Address Proof</li>              
              
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
