import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>GST REGISTRATION</h2>
          {/* <h2>Company Registration</h2> */}
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>GST Registration in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to GST Registration</h2>
        <p>GST Registration is a legal process that gives your business a unique Goods & Services Tax Identification Number (GSTIN). It is mandatory for businesses crossing the turnover threshold, making inter-state sales, or operating via e-commerce. 
            GST registration ensures compliance, allows you to collect tax, claim input tax credits, and enhances business credibility.</p>
      </div>
    </div>
  );
};

export default FirstSection;
