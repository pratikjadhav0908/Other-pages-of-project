import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>Startup Incorporation</h2>
          {/* <h2>Company Registration</h2> */}
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Startup Incorporation in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to Startup Incorporation</h2>
        <p>Startup Incorporation is the first step in giving your business a legal identity. By registering your startup as a company, you gain credibility, limited liability protection, and access to funding opportunities, while ensuring compliance with Indian corporate laws.</p>
      </div>
    </div>
  );
};

export default FirstSection;
