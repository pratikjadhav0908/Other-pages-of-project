import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Perks & Benefits of Incorporating a Pvt. Ltd. Company</h2>
          <h3>
            There are several advantages to Startup Incorporation : 
          </h3>
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Limited liability Protection.</h2>
            <p>
              Startups often need loans or credit. In partnerships, personal assets of partners are at risk if the business fails. In a private limited company, only the invested amount is at stake, protecting directors’ personal wealth.
            </p>
          </div>
          <div className="one-section">
            <h2>Better Market Image & Credibility</h2>
            <p>
              A Private Limited Company is a well-recognized business structure. Corporates, vendors, and government agencies prefer dealing with it over sole proprietorships or partnerships due to its credibility and trust factor.
            </p>
          </div>
          <div className="one-section">
            <h2>Easy fundraising and loan.</h2>
            <p>
              Pvt. Ltd. companies have better access to funding from banks, angel investors, and venture capitalists compared to LLPs and OPCs, making growth and expansion easier.
            </p>
          </div>
          <div className="one-section">
            <h2>Investor-Friendly Business Structure</h2>
            <p>
              Investors prefer Private Limited Companies because of their structured framework, transparent compliance, and simple exit process, making them the first choice for funding.
            </p>
          </div>
          <div className="one-section">
            <h2>Attracting & Retaining Talent</h2>
            <p>
              With the strong credibility of a Pvt. Ltd. structure, startups can easily hire skilled employees. Motivating staff with corporate titles and stock options helps in building long-term loyalty.
            </p>
          </div>
          <div className="one-section">
            <h2>Easy to Sell</h2>
            <p>
             Transferring ownership in a Pvt. Ltd. company is simple and cost-effective. Business sale or exit is quicker, requiring minimal documentation compared to other structures.
            </p>
          </div>
        </div>
      </div>
      <div className="requirement-section">
        <h1>Minimum Requirements for Pvt. Ltd. Registration</h1>
        <div className="remaining-section">
          <div className="two-section">
            <h2>Basic Requirements</h2>
            <ul>
                <li>Minimum 2 Shareholders</li>
              <li>
                Minimum 2 Directors (at least one must be an Indian resident)
              </li>
              <li>
                DSC (Digital Signature Certificate) for 2 promoters and 1
                witness
              </li>
              <li>DIN (Director Identification Number) for all directors</li>
              <li>
                Suggested Authorised Share Capital - ₹20,000 (Twenty Thousand only)
              </li>
              <li>Directors and Shareholders can be the same individuals</li>
            </ul>
          </div>
          <div className="two-section">
            <h2>What's Included</h2>
            <ul className="remove-dot">
              <li>✔️ DIN for 2 Directors</li>
              <li>✔️ MOA & AOA (Memorandum and Articles of Association)</li>
              <li>✔️ Customized Incorporation Master File</li>
              <li>✔️ Bank Account Opening Support</li>
              <li>✔️ Digital Signature Token for 2 Promoters & 1 Witness</li>
              <li>✔️ Certificate of Incorporation</li>
              <li>✔️ PAN & TAN (TDS) Registration</li>
              <li>✔️ Company TAN/TDS Registration</li>
              <li>✔️ PF, ESIC & Professional Tax Registration</li>
              <li>✔️ Company Name Approval</li>
              <li>✔️ Web Domain Name (1 Year)</li>
              <li>✔️ Web Hosting + 10 Email Accounts (1 Year)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
