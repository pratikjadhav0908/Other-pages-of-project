import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>ROC Return Filling </h2>
          <h2>for Pvt. Ltd.</h2>
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>ROC Return Filling for Pvt. Ltd. in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to ROC Return Filling for Pvt. Ltd.</h2>
        <p>Every Private Limited Company must file annual returns and financial statements with the Registrar of Companies (ROC) to comply with the Companies Act. Timely filing ensures legal compliance, avoids penalties, and maintains company credibility.</p>
      </div>
    </div>
  );
};

export default FirstSection;
