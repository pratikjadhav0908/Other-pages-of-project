import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>SECTION 8 NGO </h2>
          <h2>COMPANY REGISTRATION</h2>
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Incorporate Section 8 NGO Company in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to Section 8 NGO Company Registration</h2>
        <p>Section 8 NGO Company Registration is a legal way to establish a non-profit organization in India. It is formed with the objective of promoting charitable, educational, religious, cultural, social, or other useful activities. Unlike regular companies, 
          a Section 8 Company cannot distribute profits to its members; instead, all income and donations are utilized solely to achieve its objectives.</p>
      </div>
    </div>
  );
};

export default FirstSection;
