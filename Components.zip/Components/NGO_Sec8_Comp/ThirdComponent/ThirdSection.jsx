import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Key Benefits of Company Registration</h2>
          <h3>
            There are several advantages to registering a Section 8 Company:
          </h3>
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Privileges and Exemptions under Company Law.</h2>
            <p>
              Section 8 Companies are provided with multiple relaxations and privileges under the Companies 
              Act, 2013, reducing compliance requirements and making their operations easier compared to regular private or public companies.
            </p>
          </div>
          <div className="one-section">
            <h2>Non-Application of CARO (Companies Auditor’s Report Order).</h2>
            <p>
              Unlike other registered companies, Section 8 NGOs are exempted from compliance under CARO. This exemption lowers the statutory reporting burden and simplifies annual audit requirements.
            </p>
          </div>
          <div className="one-section">
            <h2>No Minimum Paid-Up Capital Requirement.</h2>
            <p>
              There is no mandatory minimum capital required to incorporate a Section 8 Company. It can be started with a nominal amount, making it accessible for social entrepreneurs and NGOs with limited resources.
            </p>
          </div>
          <div className="one-section">
            <h2>Partnership Firm as a Member</h2>
            <p>
              A unique advantage of Section 8 Companies is that a registered partnership firm can also become a member in its own capacity, which is not allowed in standard private limited companies. This allows greater flexibility in membership.
            </p>
          </div>
          <div className="one-section">
            <h2>Exemption from Stamp Duty</h2>
            <p>
              During the incorporation process, Section 8 Companies are exempted from paying stamp duty on their registration documents. This significantly reduces the cost of setting up the organization.
            </p>
          </div>
          <div className="one-section">
            <h2>Tax Benefits for Donors (Under Section 80G of the Income Tax Act)</h2>
            <p>
              Donors contributing to a Section 8 Company registered under Section 12AA and 80G of the Income Tax Act are eligible for tax deductions. This makes Section 8 Companies more attractive to philanthropists, corporates (CSR contributors), and other funding agencies.
            </p>
          </div>
        </div>
      </div>
      <div className="requirement-section">
        <h1>Section 8 Company Registration</h1>
        <div className="remaining-section">
          <div className="two-section">
            <h2>Basic Requirements</h2>
            <ul>
                <li>Shareholders: At least 2 shareholders for a Private Limited Section 8 Company and 7 shareholders for a Public Limited Section 8 Company.</li>
              <li>
                Directors: Minimum 2 Directors for a Private Limited NGO and 3 Directors for a Public Limited NGO.
              </li>
              <li>
                DIN (Director Identification Number): Every proposed Director must have a valid DIN.
                witness
              </li>
              <li>DSC (Digital Signature Certificate): All proposed Directors must obtain a Digital Signature Certificate for signing electronic documents.</li>
              <li>
                Same Person as Director & Shareholder: The same individual can act as both a Director and a Shareholder.
              </li>
              <li>Registered Office Address Proof: A valid address proof (utility bill, rent agreement with NOC, or ownership document) for the proposed registered office of the NGO.</li>
            </ul>
          </div>
          <div className="two-section">
            <h2>What's Included</h2>
            <ul className="remove-dot">
              <li>✔️ DIN for 2 Directors – Director Identification Numbers issued for compliance and recognition.</li>
              <li>✔️ MOA & AOA – Legally drafted Memorandum and Articles of Association outlining your NGO’s objectives and governance.</li>
              <li>✔️ Customized Incorporation Master File – A compiled record of all important incorporation documents.</li>
              <li>✔️ Customized Incorporation Master File – A compiled record of all important incorporation documents.</li>
              <li>✔️ Bank Account Opening Support – Assistance with preparing required documents for smooth NGO bank account opening.</li>
              <li>✔️ Digital Signature for 1 Director – For signing all e-filings and statutory documents securely.</li>
              <li>✔️ Certificate of Incorporation – The official document issued by the Registrar of Companies establishing your NGO.</li>
              <li>✔️ Company PAN Card – Mandatory for taxation and financial transactions.</li>
              <li>✔️ Company TAN/TDS Number – For compliance with tax deduction at source regulations.</li>
              <li>✔️ Company Name Approval – Approval of your NGO’s chosen name from MCA.</li>
              <li>✔️ New Incorporation Kit – A handy set of resources for quick compliance reference.</li>
              <li>✔️ Web Domain + Hosting with 10 Emails (1 Year) – Professional online presence setup for your NGO.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
