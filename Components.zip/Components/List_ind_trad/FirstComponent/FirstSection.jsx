import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>List of indian trademarks </h2>
          
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>List of indian trademarks in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to List of indian trademarks </h2>
        <p>The Indian Trademark Registry maintains a searchable database of all registered and applied trademarks in India. This list provides details such as trademark name, class, owner information, and application status, helping businesses verify brand availability and protect their intellectual property.</p>
      </div>
    </div>
  );
};

export default FirstSection;
