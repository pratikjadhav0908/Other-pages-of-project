import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>Appointment/Resignation </h2>
          <h2>of Director</h2>
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Appointment/Resignation of Director in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to Appointment/Resignation of Director</h2>
        <p>Any appointment or resignation of a company director must be filed with the Registrar of Companies (ROC) through the prescribed forms. Timely updates ensure compliance, maintain accurate records, and avoid penalties under the Companies Act.</p>
      </div>
    </div>
  );
};

export default FirstSection;
