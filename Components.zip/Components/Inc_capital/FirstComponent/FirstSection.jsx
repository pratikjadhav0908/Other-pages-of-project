import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>Increasing Capital</h2>
          
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>Increasing Capital in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to Increasing Capital</h2>
        <p>A company can increase its authorized share capital by following the prescribed legal procedures and filing necessary forms with the Registrar of Companies (ROC). This allows the company to raise additional funds while remaining fully compliant with the Companies Act.</p>
      </div>
    </div>
  );
};

export default FirstSection;
