import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Key Benefits of Trademark Search</h2>
          <h3>
            There are several advantages to Trademark Search :
          </h3>
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Protection Against Copycats.</h2>
            <p>
             Trademark search helps prevent conflicts with existing brands, ensuring that no one can easily copy or misuse your identity.
            </p>
          </div>
          <div className="one-section">
            <h2>Builds Brand Value.</h2>
            <p>
              A legally clear trademark becomes a valuable intangible asset. Many companies value their 
              brand name and logo more than physical assets, as they represent trust and recognition.
            </p>
          </div>
          <div className="one-section">
            <h2>Supports Business Growth.</h2>
            <p>
              A secure trademark enables smooth licensing,
               franchising, and royalty opportunities, helping businesses expand without legal challenges.
            </p>
          </div>
          <div className="one-section">
            <h2>Enhances Market Credibility</h2>
            <p>
              Brands with a verified ™ tag appear more professional and trustworthy, giving them an edge in the marketplace.
            </p>
          </div>
          {/* <div className="one-section">
            <h2>Easier to hire and retain employees</h2>
            <p>
              For startups, building a reliable team and retaining talent can be
              challenging. However, the credibility of a private limited
              structure makes it easier to attract skilled professionals.
              Employees gain confidence working in a recognized company and can
              be further motivated through corporate designations and stock
              option plans, ensuring long-term commitment and loyalty.
            </p>
          </div>
          <div className="one-section">
            <h2>Easy ownership transfer</h2>
            <p>
              A Private Limited company is easy to sell, requiring minimal
              documentation and low costs. Ownership transfer is simple through
              share sale, making exits faster compared to partnerships or
              proprietorships.
            </p>
          </div> */}
        </div>
      </div>
      <div className="requirement-section">
        {/* <h1>Requirements for Trademark Search</h1> */}
        <div className="remaining-section">
          <div className="two-section">
            <h2>Requirements for Trademark Search</h2> 
            <ul>
                <li>Identity proof of the trademark owner</li>
              <li>Eligibility to use the (TM) symbol within one day              </li>
              <li>
               One-page Authorization Letter
              </li>
              <li>Free Legal Search Report</li>
              <li>Soft copy of Logo (optional – application possible without logo)              </li>
              <li>Entirely Online Process</li>
            </ul>
          </div>
          {/* <div className="two-section">
            <h2>What's Included</h2>
            <ul className="remove-dot">
              <li>✔️ DIN for 2 Directors</li>
              <li>✔️ MOA & AOA (Memorandum and Articles of Association)</li>
              <li>✔️ Customized Incorporation Master File</li>
              <li>✔️ Bank Account Opening Support</li>
              <li>✔️ Digital Signature Token for 2 Promoters & 1 Witness</li>
              <li>✔️ Certificate of Incorporation</li>
              <li>✔️ Company PAN Card</li>
              <li>✔️ Company TAN/TDS Registration</li>
              <li>✔️ PF, ESIC & Professional Tax Registration</li>
              <li>✔️ Company Name Approval</li>
              <li>✔️ Web Domain Name (1 Year)</li>
              <li>✔️ Web Hosting + 10 Email Accounts (1 Year)</li>
            </ul>
          </div> */}
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
