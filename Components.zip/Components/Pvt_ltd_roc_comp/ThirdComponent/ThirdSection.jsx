import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Mandatory Compliances & Penalties</h2>
          {/* <h3>
            There are several advantages to registering a Pvt Ltd company:
          </h3> */}
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Issue of Share Certificates</h2>
            <p>
              <ul>
                <li>Must be issued within 2 months of incorporation or new allotment.</li>
                <li> <b>Penalty: </b>
                <ul>
                  <li>Company: ₹25,000 to ₹5,00,000</li>
                  <li>Directors: ₹10,000 to ₹1,00,000</li>
                </ul>
                </li>
                
              </ul>
            </p>
          </div>
          <div className="one-section">
            <h2>Statutory Registers</h2>
            <p>
              <ul>
                <li>7–8 registers must be maintained and updated regularly.</li>
                <li><b>Penalty: </b>₹50,000 to ₹3,00,000 + ₹1,000 per day for continuing default</li>
              </ul>
            </p>
          </div>
          <div className="one-section">
            <h2>Board Meeting Compliance</h2>
            <p>
              <ul>
                <li>1st Board Meeting within 30 days of incorporation</li>
                <li>At least 1 meeting per quarter</li>
                <li>Proper minutes, notices, and attendance registers must be maintained.</li>
                <li> <b>Penalty:</b>
                  <ul>
                    <li>Company: ₹25,000</li>
                    <li>Director in default: ₹5,000</li>
                    <li>Non-compliance with notice: Director penalty ₹25,000</li>
                  </ul>
                </li>
              </ul>
            </p>
          </div>
          <div className="one-section">
            <h2>Annual General Meeting (AGM) Compliance</h2>
            <p>
              <ul>
                <li>AGM to be held annually with proper notice, minutes, and attendance register.</li>
                <li> <b>Penalty for default:</b>
                  <ul>
                    <li>Company & Directors: Fine up to ₹1,00,000 + ₹5,000 per day of delay</li>
                    <li>Non-maintenance of Minutes Book:
                      <ul>
                        <li>Company: Up to ₹25,000</li>
                        <li>Directors: ₹5,000 each</li>
                      </ul>
                    </li>
                  </ul>
                </li>
              </ul>
            </p>
          </div>
          <div className="one-section">
            <h2>Annual ROC Filings (MGT-7, AOC-4, ADT-1)</h2>
            <p>
              <ul>
                <li>MGT-7 (Annual Return): Within 60 days of AGM</li>
                <li>ADT-1 (Auditor Appointment): Within 15 days of AGM</li>
                <li>AOC-4 (Financial Statements): Within 30 days of AGM</li>
                <li> <b>Penalty:</b>
                  <ul>
                    <li>Additional fees: Up to 12x normal filing fees (per form)</li>
                    <li>Company: ₹50,000 – ₹5,00,000</li>
                    <li>Directors: Imprisonment up to 6 months OR fine ₹50,000 – ₹5,00,000 OR both</li>
                  </ul>
                </li>
              </ul>
            </p>
          </div>
          
        </div>
      </div>
      
    </div>
  );
};

export default Thirdsection;
