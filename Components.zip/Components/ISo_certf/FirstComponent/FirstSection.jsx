import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>ISO certification</h2>
          
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>ISO certification in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to ISO certification</h2>
        <p>ISO certification is an international standard that ensures your business meets quality, safety, and efficiency benchmarks. Obtaining ISO certification enhances credibility, builds customer trust, improves processes, and helps your business compete in global markets.</p>
      </div>
    </div>
  );
};

export default FirstSection;
