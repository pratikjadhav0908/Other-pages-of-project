import React from "react";
import "./Thirdsection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Benefits of Public Limited Company Incorporation</h2>
          <h3>
            There are several advantages to registering a Public Ltd company:
          </h3>
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Limited liability Protection for directors personal assets.</h2>
            <p>
              Public Limited Companies protect directors’ personal savings and property. In case of losses or inability to repay loans, only the investment made in shares is at risk, keeping personal assets safe.
            </p>
          </div>
          <div className="one-section">
            <h2>Better Image and Market Credibility</h2>
            <p>
              As a widely recognized business structure, Public Limited Companies enjoy higher credibility. Corporate clients, vendors, and government agencies prefer dealing with them over proprietorships or partnerships.
            </p>
          </div>
          <div className="one-section">
            <h2>Easy to Raise Funds and Loans</h2>
            <p>
              Public Limited Companies can list on stock exchanges, raise capital from the general public, banks, institutional investors, and venture capitalists, offering more fundraising options compared to other structures.
            </p>
          </div>
          <div className="one-section">
            <h2>Investor-Friendly Structure</h2>
            <p>
              Investors favor Public Limited Companies due to their transparent structure, governance standards, and easy exit options, making them the top choice for large-scale investments.
            </p>
          </div>
          <div className="one-section">
            <h2>Easy Transfer of Shares</h2>
            <p>
              Ownership transfer is simple—just by selling shares with transfer forms. This makes entry and exit smooth for shareholders and investors alike.
            </p>
          </div>
          <div className="one-section">
            <h2>Most Suitable for Heavy Investment</h2>
            <p>
              For businesses requiring large-scale investments, Public Limited Companies are the best fit, offering scalability, credibility, and strong investor confidence.
            </p>
          </div>
        </div>
      </div>
      <div className="requirement-section">
        <h1>Public Ltd. Company Registration</h1>
        <div className="remaining-section">
          <div className="two-section">
            <h2>Basic Requirements</h2>
            <ul>
                <li>Minimum 7 Shareholders</li>
              <li>
                Minimum 3 Directors (at least one must be an Indian resident)
              </li>
              <li>
                DSC (Digital Signature Certificate) for at least 2 Directors
              </li>
              <li>DIN (Director Identification Number) for all directors</li>
              <li>
                Minimum Authorised Share Capital - ₹5,00,000 (INR Five Lakh)
              </li>
              <li>Directors and Shareholders can be the same individuals</li>
            </ul>
          </div>
          <div className="two-section">
            <h2>What's Included</h2>
            <ul className="remove-dot">
              <li>✔️ DIN for 2 Directors</li>
              <li>✔️ MOA & AOA (Memorandum and Articles of Association)</li>
              <li>✔️ Customized Incorporation Master File</li>
              <li>✔️ Bank Account Opening Support</li>
              <li>✔️ Digital Signature Token for 2 Promoters & 1 Witness</li>
              <li>✔️ Certificate of Incorporation</li>
              <li>✔️ Company PAN Card</li>
              <li>✔️ Company TAN/TDS Registration</li>
              <li>✔️ Company Name Approval</li>
              <li>✔️ New Incorporation Kit</li>
              <li>✔️ Web Domain Name (1 Year)</li>
              <li>✔️ Web Hosting + 10 Email Accounts (1 Year)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
