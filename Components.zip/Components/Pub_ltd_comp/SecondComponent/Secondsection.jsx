import React, { useState } from "react";
import "./Secondsection.css";

const panels = ["categories", "process", "document", "cost"];

const Secondsection = () => {
  const [activeClass, setActiveClass] = useState("categories");
  const [exiting, setExiting] = useState(null);

  const Appearclass = (classid) => {
    if (classid === activeClass) return;

    setExiting(activeClass);

    setTimeout(() => {
      setExiting(null);
      setActiveClass(classid);
    }, 400); 
  };
  return (
    <div className="Secondsection">
      <div className="whole-part">
        <div className="header-section">
          {panels.map((panel) => (
            <p
              key={panel}
              className={activeClass === panel ? "active-class-menu" : ""}
              onClick={() => Appearclass(panel)}
            >
              {panel === "categories" && "Company Registration Categories"}
              {panel === "process" && "Company Registration Process"}
              {panel === "document" && "Required Document for Registration"}
              {panel === "cost" && "Cost of Company Registration"}
            </p>
          ))}
        </div>
        <div className="description-section">
          <div className={`set-opacity ${
              activeClass === "categories" ? "active-class" : ""
            } ${exiting === "categories" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-first">
                <p>
                  In India, besides private limited companies, there are several
                  other types of company registrations. However, Pvt Ltd
                  incorporation continues to enjoy the highest trust among
                  customers, vendors, employees, investors, and bankers. Each
                  registration type comes with its own features, benefits, and
                  compliance requirements. To understand these better, you can
                  watch a detailed video after submitting the GET STARTED form
                  above.
                </p>
                <h3>Types of Company Registrations in India:</h3>
                <ul>
                  <li>
                    One Person Company (OPC): Best suited for solo
                    entrepreneurs, OPC allows a single individual to own all
                    shares and manage the business.
                  </li>
                  <li>
                    Limited Liability Partnership (LLP): LLP offers the
                    flexibility of a partnership while providing limited
                    liability protection to its partners.
                  </li>
                  <li>
                    Public Limited Company: Ideal for large-scale businesses, as
                    it enables the company to raise capital by offering shares
                    to the public.
                  </li>
                  <li>
                    Section 8 Company (Non-Profit): Designed for NGOs and
                    non-profit organizations aiming to promote charitable or
                    social objectives.
                  </li>
                </ul>
                <p>
                  Apart from these, there are other business structures like
                  proprietorships and partnership firms. However, since these
                  are not registered companies, they generally carry a lower
                  trust score in the market.
                </p>
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "process" ? "active-class" : ""
            } ${exiting === "process" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-second">
                <p>
                  Company Registration: Step-by-Step Process: Submit the
                  Consultation Form, and we’ll connect with you at the earliest.
                </p>
                <p>
                  The process of registering a Pvt Ltd company in India involves
                  specific legal steps, which can be outlined as follows:
                </p>
                <ul>
                  <li>
                    <b>Filling the Form :</b> Once the Registration form is
                    submitted, We will connect with you to initiate your company
                    incorporation.
                  </li>
                  <li>
                    <b>Arranging Founders’/Directors’ Documents:</b> Directors
                    and shareholders must arrange basic proof documents (as
                    detailed below) to begin the process.
                  </li>
                  <li>
                    <b>Preparation of Signing Documents:</b> The legal team
                    reviews the submitted documents and prepares incorporation
                    papers for the directors’ and shareholders’ signatures.
                  </li>
                  <li>
                    <b>Digital Signature Certificate (DSC):</b> The first step
                    is to obtain DSCs for the proposed directors. These are
                    essential for electronically signing official documents.
                  </li>
                  <li>
                    <b>Name Application & Approval:</b> The company’s proposed
                    name must be unique and relevant to its business. It can be
                    verified and applied through the MCA (Ministry of Corporate
                    Affairs) portal.
                  </li>
                  <li>
                    <b>
                      Memorandum of Association (MoA) & Articles of Association
                      (AoA):
                    </b>
                    Drafting and submitting the MoA (objectives of the company)
                    and AoA (rules and bylaws of the company).
                  </li>
                  <li>
                    <b>Incorporation Application (SPICe Form):</b> Filing the
                    SPICe form along with all required documents to the MCA.
                    This step also includes applying for the company’s PAN and
                    TAN.
                  </li>
                  <li>
                    <b>Approval & Incorporation Certificate:</b> After
                    verification, the Registrar of Companies (RoC) issues the
                    Certificate of Incorporation, confirming the company’s legal
                    existence.
                  </li>
                  <li>
                    <b>Director Identification Number (DIN):</b> Every director
                    must have a DIN, which can be obtained by filing an online
                    application.
                  </li>
                  <li>
                    <b>PAN & TAN Allocation:</b> Along with the Incorporation
                    Certificate, the company is allotted a PAN and TAN/TDS
                    number.
                  </li>
                  <li>
                    <b>Bank Account Opening:</b> A current bank account must be
                    opened in the company’s name to commence business
                    operations.
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "document" ? "active-class" : ""
            } ${exiting === "document" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-third">
                <p>
                  Here’s the list of documents needed to register a Pvt Ltd
                  company in India:
                </p>
                <ul>
                  <li>Passport-sized Photographs – Of all directors.</li>
                  <li>
                    Identity Proof of Directors & Shareholders – PAN card (for
                    Indian nationals) or Passport (for foreign nationals).
                  </li>
                  <li>
                    Address Proof – Aadhaar card, Voter ID, Passport, or Driving
                    License.
                  </li>
                  <li>
                    Residential Proof – Recent utility bills (electricity,
                    telephone, etc.) or bank statements.
                  </li>
                  <li>
                    Registered Office Proof – <br /> - If rented: Rent agreement
                    and No Objection Certificate (NOC) from the landlord. <br />{" "}
                    - If owned: Ownership documents.
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className={`set-opacity ${
              activeClass === "cost" ? "active-class" : ""
            } ${exiting === "cost" ? "exiting" : ""}`}>
            <div className="description-section-properties">
              <div className="description-section-forth">
                <p>
                  The overall cost of Pvt Ltd company registration in India
                  differs based on the number of directors, share capital, and
                  professional charges.
                </p>
                <p>Government charges for company registration include:</p>
                <ul>
                  <li>
                    DSC Token: Applicable fee per DSC (Digital Signature
                    Certificate) application.
                  </li>
                  <li>
                    Name Reservation: Fee for reserving the proposed company
                    name.
                  </li>
                  <li>
                    Form Filing Fees: Charges for filing incorporation-related
                    forms with the MCA.
                  </li>
                  <li>
                    Stamp Duty: State-specific fees that vary depending on the
                    place of incorporation.
                  </li>
                </ul>
                <p>
                  Professional fees for drafting and handling legal documents
                  form part of the extra costs.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Secondsection;
