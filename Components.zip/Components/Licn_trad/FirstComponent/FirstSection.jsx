import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>licence your trademark</h2>
          
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>licence your trademark in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to licence your trademark</h2>
        <p>Licensing your trademark allows others to use your brand legally while you retain ownership. It helps generate additional revenue, expand market presence, and protect your intellectual property rights through proper legal agreements.</p>
      </div>
    </div>
  );
};

export default FirstSection;
