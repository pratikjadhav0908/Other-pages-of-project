import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      
      <div className="requirement-section">
        <h1>DIR3 DIN KYC Filling</h1>
        <div className="remaining-section">
          <div className="two-section">
            <h2>Basic Requirements</h2>
            <ul>
                <li>PAN Card</li>
              <li>
               Aadhaar Card
              </li>
              <li>
                Bank Statement / Electricity Bill / Phone Bill (as address proof)
              </li>
              <li>Unique Email ID & Mobile Number (for OTP verification)</li>
              <li>
                Passport (if available, for additional proof)
              </li>
              <li>Digital Signature of the Director</li>
            </ul>
          </div>
          
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
