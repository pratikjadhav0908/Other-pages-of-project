import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>DIR3 DIN KYC  </h2>
          <h2>Filling</h2>
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>DIR3 DIN KYC Filling  in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to DIR3 DIN KYC Filling </h2>
        <p>DIR-3 KYC Filing is a mandatory compliance requirement for all directors in India. It ensures that the Ministry of Corporate Affairs (MCA) has updated personal details of directors, such as identity proof, address, and contact information, verified through a Digital Signature Certificate (DSC). Filing must be done annually to keep the Director Identification Number (DIN) active and avoid penalties.</p>
      </div>
    </div>
  );
};

export default FirstSection;
