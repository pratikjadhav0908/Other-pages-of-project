import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Key Benefits of MSME Udyam Registration</h2>
          <h3>
            There are several advantages to registering :
          </h3>
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>100% Collateral-Free Loans</h2>
            <p>
              Automatic loans without collateral, 12-month repayment moratorium, and full government guarantee. No guarantee fees applicable.
            </p>
          </div>
          <div className="one-section">
            <h2>₹50,000 Crore Equity Funding.</h2>
            <p>
              Government equity support for MSMEs with growth potential through the Fund of Funds scheme.
            </p>
          </div>
          <div className="one-section">
            <h2>Support for Stock Exchange Listing.</h2>
            <p>
              AEncouragement and assistance to expand size/capacity and get listed on main boards.
            </p>
          </div>
          <div className="one-section">
            <h2>Priority in Government Tenders.</h2>
            <p>
              MSMEs get preference in government procurement and tender processes.
            </p>
          </div>
          <div className="one-section">
            <h2>1% Interest Rebate on Bank OD</h2>
            <p>
              Registered MSMEs enjoy 1% exemption on overdraft interest rates.
            </p>
          </div>
          <div className="one-section">
            <h2>Concessions in Electricity Bills</h2>
            <p>
              Enterprises can apply for electricity bill concessions.
            </p>
          </div>
          <div className="one-section">
            <h2>Protection Against Delayed Payments</h2>
            <p>
              Buyers must clear payments within 45 days or pay interest at 3x the bank rate.
            </p>
          </div>
          <div className="one-section">
            <h2>50% Fee Discount on Trademarks & Patents</h2>
            <p>
              MSMEs get a 50% government subsidy on IP registrations.
            </p>
          </div>
          <div className="one-section">
            <h2>CFaster Dispute Resolution</h2>
            <p>
              MSME Facilitation Council assists in conciliation & arbitration for payment disputes.
            </p>
          </div>
        </div>
      </div>
      <div className="requirement-section">
        <h1>MSME Udyam Registration</h1>
        <div className="remaining-section">
          <div className="two-section">
            <h2>Basic Requirements</h2>
            <ul>
                 <li>1️⃣ <b>For Pvt. Ltd. / Public Ltd. / OPC </b> <br />✔️ Company PAN card <br />✔️ MOA, AOA & Incorporation Certificate <br />✔️Company Address Proof</li>
              <li>2️⃣ <b>For LLP & Partnership Firm</b> <br />✔️ Firm PAN card <br />✔️ LLP Agreement / Partnership Deed <br />✔️ Firm Address Proof</li>              
              <li>3️⃣ <b>For Proprietorship Firm</b> <br />✔️ Proprietor's PAN card <br />✔️ Shop Act / Gumasta License <br />✔️ Firm Address Proof</li>              
            </ul>
          </div>
          <div className="two-section">
            <h2>What's Included</h2>
            <ul className="remove-dot">
              <li>✔️ Micro Enterprise: Investment less than ₹1 Crore and Turnover less than ₹5 Crore.</li>
              <li>✔️ Small Enterprise: Investment less than ₹10 Crore and Turnover less than ₹50 Crore.</li>
              <li>✔️ Medium Enterprise: Investment less than ₹50 Crore and Turnover less than ₹250 Crore.</li>
              <li>✔️ Earlier, classification was different for Manufacturing and Services, based only on Investment limits.</li>
              
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Thirdsection;
