import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>MSME Udyam</h2>
          <h2>Registration</h2>
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>MSME Udyam Registration in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to MSME Udyam Registration</h2>
        <p>MSME Udyam Registration provides small businesses with multiple benefits such as collateral-free loans, priority in government tenders, electricity bill concessions, 50% discount on trademark/patent fees, faster dispute resolution, and protection against delayed payments—helping enterprises grow with government-backed support.</p>
      </div>
    </div>
  );
};

export default FirstSection;
