import "./About.css";

const About = () => {
  return (
    <div className="about">
      <div className="left"></div>
      <div className="line"></div>
      <div className="right">
        <h3 className="BD">ABOUT B&D</h3>
        <h2>Company Overview</h2>
        <h3 className="statement">
          B&D Associates, is a practicing company secretary firm based in Pune,
          India.
        </h3>
        <p>
          Bodke & Devkar Associates is a practicing Company Secretary
          firm dedicated to providing corporate legal, governance, and
          compliance solutions to businesses of all sizes. We understand that
          behind every business is a dream — and our role is to protect and
          nurture that dream through accurate, timely, and ethical guidance.
        </p>
        <p>
          From the first step of company incorporation to navigating complex legal regulations, we are your trusted partner in every stage of business growth. Our mission is to simplify legal complexities and empower companies to grow confidently.
        </p>
        <p>
          At Bodke & Devkar Associates, we believe compliance is not just about meeting deadlines — it’s about building trust, credibility, and long-term success.
        </p>
      </div>
    </div>

  );
};

export default About;
