import React from "react";
import "./Team.css";

const Team = () => {
  return (
    <div className="Team">
      <div className="leftteam">
        <h3 className="BDTeam">THE B&D</h3>
        <h2>CS Snehal Bodke</h2>
        <h3 className="teamstatement">
          She is a Associate member of the Institute of Company Secretaries of
          India.
        </h3>
        <p>
          CS Snehal Bodke is a Graduate from XYZ University. She has an
          experience of over 5 year as a practising Company Secretary.
        </p>
        <div className="skills">
          <h3>Her Skills and Strengths: </h3>
          <ul>
            <li>Deep knowledge of Companies Act, 2013 & allied laws</li>
            <li>Expertise in MCA portal filing & compliance</li>
            <li>Accuracy, confidentiality & timely delivery</li>
            <li>Strong legal drafting skills</li>
            <li>Ability to simplify legal complexities for clients</li>
            <li>Client-friendly approach & proactive solutions</li>
          </ul>
        </div>
      </div>
      <div className="lines"></div>
      <div className="rightteam"></div>
    </div>
  );
};

export default Team;
