import About from './About'
import Value from './Value'
import Team from './Team'
import './Aboutus.css'

function aboutUs() {
 

  return (
<>
<div id="About">
<div id='nav'></div>
  <h3>The B&D</h3>
  <h2>About Us</h2>
  <div><Value/></div>
</div>
<div id="firm"><About/></div>
<div id="sbodke"><Team/></div>
</>
  )
}

export default aboutUs