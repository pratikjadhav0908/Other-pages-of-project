import React from "react";
import "./Value.css";

const Value = () => {
  return (
    <div className="ourvalue">
      <div className="Value">
        <div className="leftmission">
          <h2>Our Mission</h2>
          <p>
            Our mission is to simplify complex legal processes, empower
            entrepreneurs with the right knowledge and resources, and foster a
            culture of compliance that enables businesses to operate
            confidently, grow sustainably, and achieve long-term success in a
            competitive environment.
          </p>
        </div>
        <div className="rightvision">
          <h2>Our Vision</h2>
          <p>
            Our vision is to be the trusted partner for businesses, setting new
            benchmarks in transparency, efficiency, and integrity, while
            creating an ecosystem where legal compliance becomes second nature
            and every entrepreneur can innovate, expand, and thrive without
            barriers.
          </p>
        </div>
      </div>
    </div>

  );
};

export default Value;
