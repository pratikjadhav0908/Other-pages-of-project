import React from "react";
import "../ThirdComponent/ThirdSection.css";

const Thirdsection = () => {
  return (
    <div className="last-component">
      <div className="benefits">
        <div className="benefit-title">
          <h2>Mandatory Annual Compliances For LLP</h2>
          
        </div>
        <div className="different-section">
          <div className="one-section">
            <h2>Form 11 (Annual Return of LLP).</h2>
            <p>
              
              <ul>
                <li><b>Due Date:</b> Within 60 days from the end of every financial year</li>
                <li><b>Penalty/Consequences:</b>
                <ul>
                  <li>LLP: ₹100 per day until filing is completed</li>
                  <li>Designated Partner: Penalty ranging from ₹10,000 to ₹1,00,000</li>
                  <li>ROC can issue notice and initiate legal action</li>
                  </ul>
                </li>
                
              </ul>
            </p>
          </div>
          <div className="one-section">
            <h2>Form 8 (Statement of Accounts & Solvency).</h2>
            <p>
              <ul>
                <li><b>Due Date:</b> Within 30 days from the end of 6 months after closure of every financial year</li>
                <li><b>Penalty/Consequences:</b>
                  <ul>
                    <li>Same penalty rules as Form 11 (₹100 per day delay, minimum ₹10,000)</li>
                    <li>Legal proceedings may be initiated for continued non-compliance</li>
                  </ul>
                </li>
              </ul>
            </p>
          </div>
          
          
         
        </div>
      </div>
      
    </div>
  );
};

export default Thirdsection;
