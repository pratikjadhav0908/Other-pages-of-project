import React from "react";
import "../FirstComponent/FirstSection.css";
import fill_the_form from '../../../assets/form.png'

const FirstSection = () => {
  return (
    <div className="FirstSection">
      <div className="headerbar">
        <div className="title-of-service">
          <p>The B&D</p>
          <h2>LLP Roc Complianc AMC</h2>
    
        </div>
        <div className="btn-to-service">
          <h3>Get Service</h3>
        </div>
      </div>
      <div className="method-for-service">
        <h2>HERE'S THE PROCESS</h2>
        <p>LLP Roc Complianc AMC in 4 Simple Steps</p>
        <img src={fill_the_form} alt="" />
      </div>
      <div className="step-wise-guide">
        <h2>Step-by-Step Guide to LLP Roc Complianc AMC</h2>
        <p>Running an LLP in India comes with certain mandatory annual compliances that must be filed with the Registrar of Companies (ROC). Timely filing not only avoids heavy penalties but also ensures your LLP maintains a good legal standing and credibility in the market. The two key filings every LLP must complete each year are Form 11 (Annual Return) and Form 8 (Statement of Accounts & Solvency).</p>
      </div>
    </div>
  );
};

export default FirstSection;
